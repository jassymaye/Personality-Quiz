//
//  ViewController.swift
//  Personality Quiz
//
//  Created by MXC Swift on 9/29/20.
//  Copyright © 2020 Jasmine Gillon. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

